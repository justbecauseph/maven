package town.lampas.haruhi.storage;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.OptionalLong;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.function.Supplier;

/**
 * Keeps all state in memory. It is the backend when no database is configured, and the one the contract tests run
 * against. Each call runs on a small executor and completes its future there, as the PostgreSQL backend does. One lock
 * guards the state, so calls from any thread see it consistently. Closing the instance discards everything.
 */
final class InMemoryStorage implements HaruhiStorage {
    private static final int THREADS = 2;
    private static final Comparator<StoredRevision> NEWEST_FIRST =
            Comparator.comparingLong(StoredRevision::id).reversed();

    private final Object lock = new Object();
    private final StorageExecutor executor =
            new StorageExecutor(THREADS, "haruhi-memory-storage-", StorageSupport.SHUTDOWN_GRACE);
    private final Map<UUID, Map<FlagKey, Integer>> flags = new HashMap<>();
    private final Map<UUID, Map<VisitKey, VisitRecord>> visits = new HashMap<>();
    private final List<StoredRevision> revisions = new ArrayList<>();
    private long nextRevisionId = 1;

    @Override
    public CompletableFuture<Map<FlagKey, Integer>> loadFlags(UUID characterId) {
        return locked(() -> Map.copyOf(flags.getOrDefault(characterId, Map.of())));
    }

    @Override
    public CompletableFuture<Void> writeFlags(UUID characterId, List<FlagChange> changes) {
        List<FlagChange> ordered = List.copyOf(changes);
        return locked(() -> {
            // Apply to a copy, so a change that fails part way leaves the stored flags as they were.
            Map<FlagKey, Integer> working = new HashMap<>(flags.getOrDefault(characterId, Map.of()));
            for (FlagChange change : ordered) {
                StorageSupport.requireStorable(change.key());
                if (change.value().isPresent()) {
                    working.put(change.key(), change.value().getAsInt());
                } else {
                    working.remove(change.key());
                }
            }
            if (working.isEmpty()) {
                flags.remove(characterId);
            } else {
                flags.put(characterId, working);
            }
            return null;
        });
    }

    @Override
    public CompletableFuture<Map<VisitKey, VisitRecord>> loadVisits(UUID characterId) {
        return locked(() -> Map.copyOf(visits.getOrDefault(characterId, Map.of())));
    }

    @Override
    public CompletableFuture<VisitRecord> recordVisit(UUID characterId, VisitKey key, Instant at) {
        Instant stamp = StorageSupport.micros(at);
        return locked(() -> {
            Map<VisitKey, VisitRecord> byKey = visits.computeIfAbsent(characterId, id -> new HashMap<>());
            VisitRecord previous = byKey.get(key);
            VisitRecord next = new VisitRecord(previous == null ? 1 : previous.count() + 1, stamp);
            byKey.put(key, next);
            return next;
        });
    }

    @Override
    public CompletableFuture<StoredRevision> storeRevision(
            String digest, String bundleJson, String author, Instant at) {
        Instant stamp = StorageSupport.micros(at);
        return locked(() -> {
            for (StoredRevision existing : revisions) {
                if (existing.digest().equals(digest)) {
                    return existing;
                }
            }
            StoredRevision stored = new StoredRevision(
                    nextRevisionId++, digest, bundleJson, author, stamp, Optional.empty(), Optional.empty(), false);
            revisions.add(stored);
            return stored;
        });
    }

    @Override
    public CompletableFuture<Optional<StoredRevision>> loadRevision(long revisionId) {
        return locked(() -> revisions.stream().filter(revision -> revision.id() == revisionId).findFirst());
    }

    @Override
    public CompletableFuture<Optional<StoredRevision>> activeRevision() {
        return locked(() -> revisions.stream().filter(StoredRevision::active).findFirst());
    }

    @Override
    public CompletableFuture<Void> activateRevision(long revisionId, String actor, Instant at) {
        Instant stamp = StorageSupport.micros(at);
        return locked(() -> {
            int target = indexOf(revisionId);
            for (int index = 0; index < revisions.size(); index++) {
                StoredRevision revision = revisions.get(index);
                if (index == target) {
                    revisions.set(index, withActivation(revision, Optional.of(stamp), Optional.of(actor), true));
                } else if (revision.active()) {
                    revisions.set(index,
                            withActivation(revision, revision.activatedAt(), revision.activatedBy(), false));
                }
            }
            return null;
        });
    }

    @Override
    public CompletableFuture<List<RevisionSummary>> listRevisions(OptionalLong before, int limit) {
        if (limit < 1) {
            return CompletableFuture.failedFuture(new IllegalArgumentException("limit must be positive, was " + limit));
        }
        return locked(() -> revisions.stream()
                .filter(revision -> before.isEmpty() || revision.id() < before.getAsLong())
                .sorted(NEWEST_FIRST)
                .limit(limit)
                .map(StoredRevision::summary)
                .toList());
    }

    @Override
    public String backendName() {
        return "memory";
    }

    @Override
    public void close() {
        executor.close();
    }

    /** Runs the work on the executor while holding the lock. */
    private <T> CompletableFuture<T> locked(Supplier<T> work) {
        return executor.submit(() -> {
            synchronized (lock) {
                return work.get();
            }
        });
    }

    private int indexOf(long revisionId) {
        for (int index = 0; index < revisions.size(); index++) {
            if (revisions.get(index).id() == revisionId) {
                return index;
            }
        }
        throw new IllegalArgumentException("No content revision " + revisionId);
    }

    private static StoredRevision withActivation(
            StoredRevision revision, Optional<Instant> activatedAt, Optional<String> activatedBy, boolean active) {
        return new StoredRevision(revision.id(), revision.digest(), revision.bundleJson(), revision.author(),
                revision.createdAt(), activatedAt, activatedBy, active);
    }
}
